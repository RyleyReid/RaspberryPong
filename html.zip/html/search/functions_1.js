var searchData=
[
  ['movedegree_15',['moveDegree',['../classgrbl_interface.html#aafd240805c298c88fbc014fcf57728a6',1,'grblInterface']]]
];
