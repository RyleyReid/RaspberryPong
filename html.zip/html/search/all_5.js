var searchData=
[
  ['resetx_6',['resetX',['../classgrbl_interface.html#abee214660f49d6c06032ec9aa4eeb418',1,'grblInterface']]],
  ['resety_7',['resetY',['../classgrbl_interface.html#a59c530d7b3c69da560b158c5aecba296',1,'grblInterface']]]
];
