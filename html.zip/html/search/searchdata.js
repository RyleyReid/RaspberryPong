var indexSectionsWithContent =
{
  0: "cfgmors",
  1: "cgs",
  2: "fmors"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions"
};

